import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css'



class App extends React.Component {

  redirect=(e) => {
    e.preventDefault();
    window.location.href='http://google.com';
    }
  render(){
  return (
    <div className="App">
      <header className="App-header">
      <button className="btn-success" onClick={this.redirect}> Go to Utility App</button>
      </header>
    </div>
  );
}
}

export default App;
